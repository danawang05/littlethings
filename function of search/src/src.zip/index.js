import React from 'react';
import ReactDOM from 'react-dom';
// import App from './demo1/App.js';
// import App from './demo2/App.js';
import App from './demo3/App.js';

ReactDOM.render(
  <App/>,
  document.getElementById('root')
);