import React, { Component } from 'react';

// ref 可以找到原生的dom元素
// 最佳实践，可以用react解决的问题，尽量不要用 ref

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  componentDidMount() {
    const {canvas} = this;
    canvas.style.border = '2px solid #000';
    const ctx = canvas.getContext('2d');
    
    let W = canvas.width;
    let H = canvas.height;
    
    ctx.beginPath();
    ctx.lineWidth = 10;
    ctx.arc(W/2, H/2, 100, 0, Math.PI*3/2);
    ctx.stroke();
    
    const {input} = this;
    input.style.display = 'block';
    input.style.width = '200px';
    input.style.height = '50px';
    input.onchange = () => {
      console.log('原生的onchange');
    }
  }
  handleChange(e){
    console.log(e.target.value);
  }
  render() {
    return (
      <div ref={(box) => {this.box = box}}>
        <canvas width="800" height="600"
          ref={(canvas) => {this.canvas = canvas}}
        ></canvas>
        <input onChange={this.handleChange} type="text" ref={(input) => {this.input = input}}/>
      </div>
    );
  }

}

export default App;