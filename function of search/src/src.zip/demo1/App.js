import React from 'react'
import ReactDOM from 'react-dom'
import { Transition } from 'react-transition-group'

const duration = 300;

const defaultStyle = {
  transition: `${duration}ms ease-in-out`,
  opacity: 0,
  transform: 'translate(100px)',
  padding: 20,
  display: 'inline-block',
  backgroundColor: '#8787d8'
}

const transitionStyles = {
  entering: { opacity: 0,  transform: 'translate(100px)'},
  entered: { opacity: 1,  transform: 'translate(0)' },
};

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false
    };
  }
  handleToggle() {
    this.setState(({ show }) => ({
      show: !show
    }))
  }
  render() {
    const { show } = this.state
    return (
      <div>
        <button onClick={() => this.handleToggle()}>
          Click to toggle
        </button>
        <div>
          <Transition in={show} timeout={duration}>
            {(state) => (
              <div style={{
                ...defaultStyle,
                ...transitionStyles[state]
              }}>
                I'm A fade Transition!
              </div>
            )}
          </Transition>
        </div>
      </div>
    )
  }
}

export default App;